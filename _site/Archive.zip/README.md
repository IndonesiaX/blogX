# Jekyll blog of IndonesiaX Kabar. 

Themes forked from [Long Haul](https://github.com/brianmaierjr/long-haul) by [@brianmaierjr](https://twitter.com/brianmaierjr).

-----



